<?php
include("../koneksi.php");
require_once("auth.php");
$id = $_SESSION['user']['id'];
?>
<!DOCTYPE html>
<html lang="en">
<?php
include "template/header.php";
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include "template/sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include "template/topbar.php";
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Info</h1>
                    <div class="text-right mb-2">
                        <a href="tambah_info.php" class="btn btn-success">+Tambah Info</a>
                    </div>
                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Info</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Judul</th>
                                            <th>Isi</th>
                                            <th>Tanggal</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>No</th>
                                            <th>Judul</th>
                                            <th>Isi</th>
                                            <th>Tanggal</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM info";
                                        $query = mysqli_query($kon, $sql);
                                        $no = 1;
                                        while ($data = mysqli_fetch_array($query)) :
                                        ?>
                                            <tr>
                                                <td><?= $no; ?></td>
                                                <td><?= $data['judul'] ?></td>
                                                <td><?php echo implode(' ', array_slice(explode(' ', $data['isi']), 0, 20)); ?>...</td>
                                                <td><?= $data['date_created']; ?></td>
                                                <td>
                                                    <a href="detail_info.php?id=<?= $data['id'] ?>" class="btn btn-xs btn-warning small"><i class="fa fa-edit" title="Edit"></i></a>
                                                    <a href="hapus_info.php?id=<?= $data['id'] ?>" class="btn btn-xs btn-danger small" onclick="return confirm('Yakin menghapus user ini?')"><i class="fa fa-trash" title="Hapus"></i></a>
                                                </td>
                                            </tr>
                                        <?php
                                            $no++;
                                        endwhile;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            include "template/footer.php";
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <?php
    include "template/logout_modal.php";
    include "template/script.php";
    ?>


</body>

</html>