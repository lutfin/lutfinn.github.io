<?php
include("../koneksi.php");
require_once("auth.php");

$id = $_SESSION['user']['id'];
?>
<!DOCTYPE html>
<html lang="en">
<?php
include "template/header.php";
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include "template/sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include "template/topbar.php";
                ?>
                <!-- End of Topbar -->


                <div class="container" Id="jadwal">

                    <h2 class="page-section-heading text-center text-uppercase text-black">JadwalKU</h2><br><br>
                    <!-- Begin Page Content -->

                    <div>
                        <!-- DataTales Example -->
                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary">JadwalKU</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <thead>
                                            <tr>
                                                <th>Tanggal</th>
                                                <th>Jam</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </thead>
                                        <tfoot>
                                            <tr>
                                                <th>Tanggal</th>
                                                <th>Jam</th>
                                                <th>Aksi</th>
                                            </tr>
                                        </tfoot>
                                        <tbody>
                                            <?php
                                            $today = date('Y-m-j', time());
                                            $query = mysqli_query($kon, "SELECT pesanan.*, users.nama_depan FROM pesanan LEFT JOIN users on pesanan.user_id = users.id WHERE pesanan.user_id = '$id' AND pesanan.tanggal_pesanan >= '$today'");
                                            while ($data = mysqli_fetch_assoc($query)) :
                                            ?>
                                                <tr>
                                                    <td><?= $data['tanggal_pesanan'] ?></td>
                                                    <td><?= $data['jam_pesan'] . ":00" ?></td>
                                                    <td><a class="btn btn-danger" href="batal.php?id=<?= $data['id'] ?>" onclick="return confirm('Yakin ingin menghapus pesanan ini?')">BATAL</a></td>
                                                </tr>
                                            <?php
                                            endwhile;
                                            ?>
                                        </tbody>
                                    </table>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- End of jADWAL -->

                </div>
                <!-- End of Main Content -->

                <!-- Footer -->
                <?php
                include "template/footer.php";
                ?>
                <!-- End of Footer -->

            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <?php
        include "template/logout_modal.php";
        include "template/script.php";
        ?>


</body>

</html>