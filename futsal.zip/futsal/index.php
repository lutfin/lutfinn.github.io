<!doctype html>
<html lang="en">

<?php include("template/header.php") ?>

<body id="page-top">


  <!--Navbar Start-->
  <?php include("template/navbar.php") ?>
  <!--Navbar End-->
  <!--Carousel Start-->

  <div id="carouselExampleCaptions" class="carousel slide" data-ride="carousel">
    <ol class="carousel-indicators">
      <li data-target="#carouselExampleCaptions" data-slide-to="0" class="active"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="1"></li>
      <li data-target="#carouselExampleCaptions" data-slide-to="2"></li>
    </ol>
    <div class="carousel-inner">
      <div class="carousel-item active">
        <img src="gambar/1.png" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
        </div>
      </div>
      <div class="carousel-item">
        <img src="gambar/2.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
        </div>
      </div>
      <div class="carousel-item">
        <img src="gambar/3.jpg" class="d-block w-100" alt="...">
        <div class="carousel-caption d-none d-md-block">
        </div>
      </div>
    </div>
    <a class="carousel-control-prev" href="#carouselExampleCaptions" role="button" data-slide="prev">
      <span class="carousel-control-prev-icon" aria-hidden="true"></span>
      <span class="sr-only">Previous</span>
    </a>
    <a class="carousel-control-next" href="#carouselExampleCaptions" role="button" data-slide="next">
      <span class="carousel-control-next-icon" aria-hidden="true"></span>
      <span class="sr-only">Next</span>
    </a>
  </div>

  <!--Carousel End-->


  <br>
  <br>

  <!--Column Start-->

  <div class="container" Id="info">
    <br>
    <br>
    <br>
    <br>
    <br>
    <h2 class="page-section-heading text-center text-uppercase text-black">Info</h2><br><br>
    <div class="card-columns">
      <?php
      include("koneksi.php");
      $sql = "SELECT * FROM info";
      $query = mysqli_query($kon, $sql);
      $no = 1;
      while ($data = mysqli_fetch_array($query)) :


      ?>

        <div class="card">
          <img src="gambar/<?= $data['gambar'] ?>" class="card-img-top" alt="...">
          <div class="card-body">
            <h5 class="card-title"><?= $data['judul'] ?></h5>

            <p class="text-justify"><?php echo implode(' ', array_slice(explode(' ', $data['isi']), 0, 20)); ?>...
              <br>

            </p>
            <p class="text-left"><small class="text-muted">Posted on: <?= $data['date_created'] ?></small></p>
            <a href="info.php?id=<?= $data['id'] ?>" class="btn btn-primary">Info Lanjut</a>
          </div>
        </div>

      <?php
        $no++;
      endwhile; ?>
    </div>
    <br>
  </div>
  </div>
  <br>
  <br>
  <br>

  <!--Column End-->

  <!--Ember Start-->

  <!--Ember End-->

  <!--Footer Start-->
  <?php include("template/footer.php") ?>
</body>

</html>