<?php

include("../koneksi.php");
require_once("auth.php");

$id = $_GET['id'];

mysqli_query($kon, "UPDATE users SET status = '0' WHERE id = '$id'");

header("location:user.php");
