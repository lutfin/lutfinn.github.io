<?php

include("../koneksi.php");
require_once("auth.php");

$id = $_GET['id'];

mysqli_query($kon, "DELETE FROM pesanan WHERE id = '$id'");


header("location:semua_jadwal.php");
