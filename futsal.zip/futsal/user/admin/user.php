<?php
include("../koneksi.php");
require_once("auth.php");
$id = $_SESSION['user']['id'];
?>
<!DOCTYPE html>
<html lang="en">
<?php
include "template/header.php";
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include "template/sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include "template/topbar.php";
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">User</h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">User</h6>
                        </div>
                        <div class="card-body">
                            <div class="table-responsive">
                                <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                    <thead>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Email</th>
                                            <th>No HP</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </thead>
                                    <tfoot>
                                        <tr>
                                            <th>No</th>
                                            <th>Nama</th>
                                            <th>Email</th>
                                            <th>No Hp</th>
                                            <th>Aksi</th>
                                        </tr>
                                    </tfoot>
                                    <tbody>
                                        <?php
                                        $sql = "SELECT * FROM users WHERE status = '1'";
                                        $query = mysqli_query($kon, $sql);
                                        $no = 1;
                                        while ($data = mysqli_fetch_array($query)) :
                                            $id_user = $data['id'];
                                        ?>
                                            <tr>
                                                <td><?= $no; ?></td>
                                                <td><a href="profile.php?id=<?= $id_user ?>"><?= $data['nama_depan'] . " " . $data['nama_belakang']; ?></a></td>
                                                <td><?= $data['email']; ?></td>
                                                <td><?= $data['no_hp']; ?></td>
                                                <td>
                                                    <a href="profile.php?id=<?= $id_user ?>" class="btn btn-xs btn-warning small"><i class="fa fa-edit" title="Edit"></i></a>
                                                    <a href="hapus_user.php?id=<?= $id_user ?>" class="btn btn-xs btn-danger small" onclick="return confirm('Yakin menghapus user ini?')"><i class="fa fa-trash" title="Hapus"></i></a>
                                                </td>
                                            </tr>
                                        <?php
                                            $no++;
                                        endwhile;
                                        ?>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            include "template/footer.php";
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <?php
    include "template/logout_modal.php";
    include "template/script.php";
    ?>


</body>

</html>