<?php

include("../koneksi.php");
require_once("auth.php");

$id = $_GET['id'];

mysqli_query($kon, "DELETE FROM info WHERE id = '$id'");


header("location:info.php");
