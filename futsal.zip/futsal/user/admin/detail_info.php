<?php
require_once("auth.php");
include("../koneksi.php");

$id = $_GET['id'];
if (isset($_POST['info'])) {
    if ($_FILES['gambar']['name'] != null) {
        $foto = $_FILES['gambar']['name'];
        $foto_lama = $_POST['foto_lama'];
        $tmp = $_FILES['gambar']['tmp_name'];
        $ex = explode('.', $foto);
        $nama_baru = 'foto_' . time() . '.' . strtolower($ex[1]);

        $daftar_extensi = ['jpg', 'png', 'jpeg'];
        $extensi = strtolower(end($ex));

        if (in_array($extensi, $daftar_extensi) === true) {
            $pindah = move_uploaded_file($tmp, '../../gambar/' . $nama_baru);
            if (file_exists('../../gambar/' . $foto_lama)) {
                unlink('../../gambar/' . $foto_lama);
            }
        }
    } else {
        $nama_baru = $_POST['foto_lama'];
    }



    // ambil data dari formulir
    $judul = $_POST['judul'];
    $isi = $_POST['isi'];

    // buat query update
    $sql_up = "UPDATE info SET judul='$judul',isi='$isi',gambar = '$nama_baru' WHERE id = '$id'";
    $query_up = mysqli_query($kon, $sql_up);

    // apakah query update berhasil?
    if ($query_up) {
        echo "<script>alert('Data berhasil disimpan');</script>";
    } else {
        // kalau gagal tampilkan pesan
        die("Gagal menyimpan perubahan...");
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<?php
include "template/header.php";
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include "template/sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include "template/topbar.php";
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">



                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Info</h6>
                        </div>
                        <div class="card-body">
                            <?php
                            $sql = "SELECT * FROM info WHERE id = '$id'";
                            $query = mysqli_query($kon, $sql);

                            $data = mysqli_fetch_array($query);

                            ?>
                            <form action="" method="POST" enctype="multipart/form-data">

                                <div class="form-group">
                                    <label for="judul">judul</label>
                                    <input type="text" class="form-control" id="judul" name="judul" placeholder="judul" value="<?= $data['judul']; ?>">
                                </div>
                                <div class="form-group">
                                    <label for="isi">Isi</label>
                                    <textarea name="isi" id="ckeditor" class="ckeditor form-control"><?= $data['isi']; ?></textarea>
                                </div>
                                <div class="form-group">
                                    <label for="gambar">Gambar</label>
                                    <br>
                                    <img src="../../gambar/<?= $data['gambar']; ?>" style="width: 10rem" class="mr-3">
                                    <input type="hidden" name="foto_lama" value="<?= $data['gambar'] ?>">
                                    <input type="file" name="gambar" value="">
                                </div>

                                <button type=" submit" value="info" name="info" class="btn btn-primary my-1">Submit</button>
                            </form>
                        </div>

                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            include "template/footer.php";
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <?php
    include "template/logout_modal.php";
    include "template/script.php";
    ?>

</body>

</html>