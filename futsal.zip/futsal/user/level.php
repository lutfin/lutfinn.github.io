<?php

session_start();
if (!isset($_SESSION["user"])) {
    header("Location: login.php");
} else {
    if ($_SESSION["user"]["level"] == 0) {
        header("Location: admin/index.php");
    } else {
        header("Location: index.php");
    }
}
