<?php
include("koneksi.php");
$id = $_GET['id'];
$sql = "SELECT * FROM info WHERE id = '$id'";
$query = mysqli_query($kon, $sql);

$data = mysqli_fetch_array($query);

?>
<!doctype html>
<html lang="en">
<?php include("template/header.php") ?>

<body id="page-top">

    <!--style.css-->
    <link rel="stylesheet" href="style.css">
    <link rel="stylesheet" href="all.css">

    <!--Navbar Start-->
    <!--Navbar Start-->
    <?php include("template/navbar.php") ?>
    <!--Navbar End-->
    <!--Navbar End-->

    <br><br><br>
    </head>
    <!--Indent Start-->
    <style>

    </style>
    <!--Indent End-->
    <!--Posting Start-->

    <div class="container">
        <div class="container">
            <div class="row">
                <div class="media">
                    <img src="gambar/<?= $data['gambar']; ?>" style="width: 10rem" class="mr-3"">
                    <div class=" media-body">
                    <h1 class="mt-0"><?= $data['judul']; ?></h1>
                    <p class="card-text"><small class="text-muted">Posted on: <?= $data['date_created']; ?></small></p>
                </div>
            </div>
            <br>
            <br>


            <div class="Post">
                <br>
                <div class="container">
                    <div class="row">
                        <div class="col-lg-6">
                            <div class="indent">
                                <?= $data['isi']; ?>
                            </div>

                        </div>
                        <div class="col-lg-4">
                            <br>
                            <img width="500" src="gambar/<?= $data['gambar']; ?>" style="width: 500px;">
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
    </div>
    </div>
    </div>
    <!--Posting End-->


    <!--Footer Start-->
    <?php include("template/footer.php"); ?>
</body>

</html>