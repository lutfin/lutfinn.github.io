<main role="main" class="container" style="height:20vh">
</main>

<div id="footer" class="footer1">
    <div class="row">
        <div class="col">
            <div class="card1" style="width: 20rem;">
                <div class="card-body">
                    <h5 class="card-title">Tentang Kami</h5>
                    <p class="card-text">Real Magrib FC.</p>
                </div>
            </div>
            <div class="card1" style="width: 20rem;">
                <div class="card-body">
                    <h5 class="card-title">Alamat</h5>
                    <p class="card-text">Jl.H.Sirun No.23, RT.07/RW.01,Ceger, Kec. Cipayung, Kota Jakarta Timur 13820, Indonesia<br>
                        <img src="gambar/faviconIns.ico" alt="instaIcon"> Instagram: <a href="https://www.instagram.com/lutfi.gg/" title="Futsal"><span> Real Magrib FC</span></a><br><br>
                        <img src="gambar/whatsIco.jpg" alt="whatsappIcon"> Whatsapp: <br>0898-8137-725</p>
                    </p>
                </div>
            </div>
        </div>
        <div class="col">
            <div class="card-body">
                <h5 class="card-title">Temukan Kami</h5>
                <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3965.6686977152253!2d106.8852451153705!3d-6.3071846634820155!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x2e69ed680a6faa99%3A0x5593832a128cda71!2sJl.%20H.%20Sirun%20No.23%2C%20RT.6%2FRW.1%2C%20Ceger%2C%20Kec.%20Cipayung%2C%20Kota%20Jakarta%20Timur%2C%20Daerah%20Khusus%20Ibukota%20Jakarta%2013820!5e0!3m2!1sen!2sid!4v1608784618407!5m2!1sen!2sid" width="400" height="225" frameborder="0" style="border:0;" allowfullscreen="" aria-hidden="false" tabindex="0"></iframe>
            </div>
        </div>
    </div>
    <div class="container">
        <div class="container">
            <div class="footer2">
                <div class="tg-container">
                    <div class="tg-inner-wrap">
                        <div class="copy-right js-scroll-trigger">Copyright © 2020 <a href="#page-top" title="Futsal"><span>Futsal</span></a>. Made by Real Magrib FC.
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <br>
        <!--Footer End-->
        <!--Pertombolan-->
        <a class="gotopbtn" href="#"><i class="fas fa-arrow-up"></i> </a>
        <a class="whatsappButton" href="https://api.whatsapp.com/send?phone=628988137725&text=Halo%20Admin%20Futsal"><img src="gambar/whatsappButton.png" alt=""></a>
        <!-- Optional JavaScript -->
        <!-- jQuery first, then Popper.js, then Bootstrap JS -->
        <script src="js/jquery-3.5.1.slim.min.js"></script>
        <script src="js/popper.min.js"></script>
        <script src="js/bootstrap.min.js"></script>