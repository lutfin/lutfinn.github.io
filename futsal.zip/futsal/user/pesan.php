<?php

include("../koneksi.php");
require_once("auth.php");

$id = $_SESSION['user']['id'];
$tanggal = $_GET['tanggal'];
$jam = $_GET['jam'];


$sql_up = "INSERT INTO pesanan(user_id,tanggal_pesanan,jam_pesan,status)VALUES('$id','$tanggal','$jam','Sudah Dipesan')";
$query_up = mysqli_query($kon, $sql_up);

// apakah query update berhasil?
if ($query_up) {
    echo "<script>alert('Berhasil');</script>";
    header('location:jadwal.php?date=' . $tanggal);
} else {
    // kalau gagal tampilkan pesan
    die("Gagal menyimpan perubahan...");
}
