<?php
include("../koneksi.php");
require_once("auth.php");
$id = $_SESSION['user']['id'];
if (isset($_GET['date'])) {
    $date_get = $_GET['date'];
} else {
    $date_get = null;
}
?>
<!DOCTYPE html>
<html lang="en">
<?php
include "template/header.php";
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include "template/sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include "template/topbar.php";
                ?>
                <!-- End of Topbar -->


                <div class="container" Id="jadwal">

                    <h2 class="page-section-heading text-center text-uppercase text-black">Jadwal</h2><br><br>
                    <!-- Begin Page Content -->

                    <div>

                        <?php
                        // Set your timezone!!
                        date_default_timezone_set('Asia/Jakarta');

                        // Get prev & next month
                        if (isset($_GET['ym'])) {
                            $ym = $_GET['ym'];
                        } else {
                            // This month
                            $ym = date('Y-m');
                        }

                        // Check format
                        $timestamp = strtotime($ym, "-01");
                        if ($timestamp === false) {
                            $timestamp = time();
                        }

                        // Today
                        $today = date('Y-m-j', time());

                        // For H3 title
                        $html_title = date('M - Y', $timestamp);

                        // Create prev & next month link     mktime(hour,minute,second,month,day,year)
                        $prev = date('Y-m', mktime(0, 0, 0, date('m', $timestamp) - 1, 1, date('Y', $timestamp)));
                        $next = date('Y-m', mktime(0, 0, 0, date('m', $timestamp) + 1, 1, date('Y', $timestamp)));

                        // Number of days in the month
                        $day_count = date('t', $timestamp);

                        // 0:Sun 1:Mon 2:Tue ...
                        $str = date('w', mktime(0, 0, 0, date('m', $timestamp), 1, date('Y', $timestamp)));


                        // Create Calendar!!
                        $weeks = array();
                        $week = '';

                        // Add empty cell
                        $week .= str_repeat('<td></td>', $str);

                        for ($day = 1; $day <= $day_count; $day++, $str++) {

                            $date = $ym . '-' . $day;

                            if ($today == $date) {
                                $week .= '<td class="today"><a class="today" href="jadwal.php?date=' . $date . '">' . $day . '</a>';
                            } else {
                                $week .= '<td><a href="jadwal.php?date=' . $date . '">' . $day . '</a>';
                            }
                            $week .= '</td>';

                            // End of the week OR End of the month
                            if ($str % 7 == 6 || $day == $day_count) {

                                if ($day == $day_count) {
                                    // Add empty cell
                                    $week .= str_repeat('<td></td>', 6 - ($str % 7));
                                }

                                $weeks[] = '<tr>' . $week . '</tr>';

                                // Prepare for new week
                                $week = '';
                            }
                        }

                        ?>

                        <!------ Include the above in your HEAD tag ---------->
                        <style>
                            .today {
                                background: #66b0ff;
                                color: #FFFFFF;
                            }

                            th:nth-of-type(7),
                            td:nth-of-type(7) a {
                                color: blue;
                            }



                            th:nth-of-type(1),
                            td:nth-of-type(1) a {
                                color: red;
                            }



                            tr:first-child th {
                                background-color: #F6F6F6;
                                text-align: center;
                                font-size: 15px;
                            }

                            th {
                                text-align: center;
                            }


                            td {
                                text-align: center;
                            }
                        </style>
                        <script src="js/jquery-1.11.1.min.js"></script>




                        <div class="card shadow mb-4">
                            <div class="card-header py-3">
                                <h6 class="m-0 font-weight-bold text-primary"><i class="far fa-calendar-alt"></i>  Calendar</h6>
                            </div>
                            <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                        <tr>
                                            <th colspan="2"><a href="?ym=<?php echo $prev; ?>"><i class="far fa-caret-square-left"></i></a></th>
                                            <th colspan="3">
                                                <?php echo $html_title; ?>
                                            </th>
                                            <th colspan="2"><a href="?ym=<?php echo $next; ?>"><i class="far fa-caret-square-right"></i></a></th>
                                        </tr>
                                        <tr>
                                            <th>S</th>
                                            <th>M</th>
                                            <th>T</th>
                                            <th>W</th>
                                            <th>T</th>
                                            <th>F</th>
                                            <th>S</th>
                                        </tr>

                                        <?php
                                        foreach ($weeks as $week) {
                                            echo $week;
                                        };
                                        ?>
                                    </table>

                                </div>
                            </div>


                        </div>
                        <?php if ($date_get) : ?>
                            <!-- DataTales Example -->
                            <div class="card shadow mb-4">
                                <div class="card-header py-3">
                                    <h6 class="m-0 font-weight-bold text-primary">Jadwal <?= $date_get ?></h6>
                                </div>
                                <div class="card-body">
                                    <div class="table-responsive">
                                        <table class="table table-bordered" id="dataTable" width="100%" cellspacing="0">
                                            <thead>
                                                <tr>
                                                    <th>Jam</th>
                                                    <th>Nama Pemesan</th>
                                                    <th>status</th>
                                                </tr>
                                            </thead>
                                            <tfoot>
                                                <tr>
                                                    <th>Jam</th>
                                                    <th>Nama Pemesan</th>
                                                    <th>status</th>
                                                </tr>
                                            </tfoot>
                                            <tbody>
                                                <?php
                                                $jam = 1;
                                                $jam_no = 0;
                                                while ($jam <= 24) :
                                                    $query = mysqli_query($kon, "SELECT pesanan.*, users.nama_depan FROM pesanan LEFT JOIN users on pesanan.user_id = users.id WHERE tanggal_pesanan = '$date_get'");
                                                    while ($data = mysqli_fetch_assoc($query)) :
                                                        $jam_no = 0;
                                                        if ($jam == $data['jam_pesan']) {
                                                            $jam_no = 1;
                                                ?>
                                                            <tr>
                                                                <td><?= $data['jam_pesan'] . ":00" ?></td>
                                                                <td><?= $data['nama_depan'] ?></td>
                                                                <td style="color: blue;"><?= $data['status']  ?></td>
                                                            </tr>
                                                        <?php
                                                            break;
                                                        }
                                                    endwhile;
                                                    if ($jam_no == 0) {
                                                        ?>
                                                        <tr>
                                                            <td><?= $jam . ":00" ?></td>
                                                            <td>-</td>
                                                            <td style="color:red;">Belum dipesan</td>
                                                        </tr>
                                                <?php
                                                    }
                                                    $jam++;
                                                endwhile;
                                                ?>
                                            </tbody>
                                        </table>
                                    </div>
                                </div>
                            </div>
                        <?php endif; ?>

                    </div>

                    <!-- End of jADWAL -->

                </div>
                <!-- End of Main Content -->

                <!-- Footer -->
                <?php
                include "template/footer.php";
                ?>
                <!-- End of Footer -->

            </div>
            <!-- End of Content Wrapper -->

        </div>
        <!-- End of Page Wrapper -->

        <!-- Scroll to Top Button-->
        <a class="scroll-to-top rounded" href="#page-top">
            <i class="fas fa-angle-up"></i>
        </a>

        <!-- Logout Modal-->
        <?php
        include "template/logout_modal.php";
        include "template/script.php";
        ?>


</body>

</html>