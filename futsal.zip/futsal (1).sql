-- phpMyAdmin SQL Dump
-- version 5.0.2
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Waktu pembuatan: 24 Des 2020 pada 10.17
-- Versi server: 10.4.11-MariaDB
-- Versi PHP: 7.4.5

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `futsal`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `info`
--

CREATE TABLE `info` (
  `id` int(10) NOT NULL,
  `judul` varchar(255) NOT NULL,
  `isi` longtext NOT NULL,
  `gambar` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `info`
--

INSERT INTO `info` (`id`, `judul`, `isi`, `gambar`, `date_created`) VALUES
(1, 'Libur Tahun Baru 2', '<p>Hari Pertama<br />Destinasi yang dikunjungi: Air Terjun Telunjuk Raung, TN Alas Purwo<br /><br />07.30 &ndash; 08.00 Penjemputan di Bandara Banyuwangi/ Hotel<br />08.00 &ndash; 09.00 Perjalanan ke Air Terjun Telunjuk Raung<br />09.00 &ndash; 10.00 Explore Air Terjun Telunjuk Raung<br />10.00 &ndash; 11.00 Perjalanan ke TN Alas Purwo<br />11.00 &ndash; 11.15 Memasuki area TN Alas Purwo<br />11.15 &ndash; 11.45 Situs kawitan dan Pura giri saloka, lokasi ini dipercaya sebagai jejak akhir hindu di Pulau Jawa<br />11.45 &ndash; 12.45 Savana Sadengan, melihat aktifitas satwa liar disini (banteng, merak dan rusa) dan makan siang (lunch box yang sudah kami siapkan)<br />12.45 &ndash; 13.00 Perjalanan menuju pantai Trianggulasi<br />13.00 &ndash; 13.30 Pantai Trianggulasi, menikmati keindahan pantai berpasir putih dan masih lumayan sepi<br />14.00 &ndash; 14.30 Menuju ke Goa Istana<br />14.30 &ndash; 15.00 Goa Istana, kita akan masuk sampai mulut goa dan melihat jejak &ndash; jejak petapa di goa ini.<br />15.00 &ndash; 16.00 Perjalanan ke pantai G-Land (dengan 4 WD jeep)<br />16.00 &ndash; 17.30 Pantai G-Land, menikmati keindahan pantai yang dikagumi para surfer dunia. Kita juga bisa menikmati keindahan sunset dari pantai ini.<br />17.30 &ndash; 20.00 Perjalanan ke Hotel, Dinner<br />20.00 Hotel, check in dan istirahat<br /><br />Hari Kedua Destinasi yang dikunjungi: De Jawatan Benculuk, Agro Buah Naga, Pantai Mustika, Pantai Wedi Ireng, Pantai Pulau Merah.<br /><br />07.30 &ndash; 08.00 Penjemputan di Hotel<br />08.00 &ndash; 09.00 Perjalanan menuju hutan trembesi &ldquo;De Jawatan Benculuk&rdquo;<br />09.00 &ndash; 10.00 De Jawatan Benculuk, menikmati keindahan area hutan trembesi yang mirip dengan setting film the lord of the rings<br />10.00 &ndash; 11.00 Menuju agro buah naga<br />11.00 &ndash; 12.00 Agro buah naga, berkeliling kebun dan memetik buah naga yang bisa langsung kita nikmati disini.<br />12.00 &ndash; 13.00 Makan siang dan sholat<br />13.30 - 13.30 Perjalanan ke pantai Mustika<br />13.30 &ndash; 14.30 Pantai Mustika, menikmati keindahan pantai Mustika yang dipenuhi dengan perahu-perahu nelayan kemudian menyebrang ke pantai Wedi Ireng dengan perahu tradisional.<br />14.30 &ndash; 15.30 Pantai Wedi Ireng, menikmati keindahan pantai Wedi Ireng yang memiliki ombak yg cukup tenang<br />15.30 &ndash; 16.15 Menuju kembali ke pantai Mustika, dilanjutkan ke pantai Pulau Merah<br />16.15 &ndash; 17.30 Pantai Pulau Merah, menikmati keindahan pantai Pulau Merah dan eksotisnya sunset di pantai ini<br />17.30 &ndash; 18.30 Perjalanan ke Nasi tempong mbok Har<br />18.30 &ndash; 19.00 Makan malam<br />19.00 &ndash; 20.00 Melanjutkan perjalanan ke hotel<br />20.00 &ndash; Hotel, check in dan istirahat<br />*Jika Pantai Teluk Ijo menjadi wishlist anda, maka pantai Wedi Ireng bisa kita ganti dengan pantai Teluk Ijo. Dengan catatan waktu tempuh akan lebih lama.<br /><br />Hari Ketiga Destinasi Yang dikunjungi: Bangsring Underwater, Waduk bajulmati, TN Baluran (Savana Bekol dan Pantai Bama)<br />07.30 &ndash; 08.00 Penjemputan di Hotel<br />08.00 &ndash; 08.30 Perjalanan menuju Bangsring Underwater<br />08.30 &ndash; 10.00 Bangsring Underwater, snorkeling untuk menikmati keindahan bawah laut pantai Bangsring<br />10.00 &ndash; 11.00 Perjalanan menuju Waduk Bajulmati<br />11.00 &ndash; 11.30 Waduk Bajulmati, menimati keindahan Waduk Bajulmati.<br />11.30 &ndash; 12.30 Makan siang<br />12.30 &ndash; 13.00 Perjalanan ke pantai Bama<br />13.30 &ndash; 14.30 Pantai Bama, menikmati keindahaan pantai Bama dengan ombaknya yang tenang dan kita juga bisa trekking ke area hutan mangrove<br />14.30 &ndash; 15.00 Menuju Savana Bekol<br />15.00 &ndash; 16.00 Savana bekol, menikmati savanna bekol dan jika beruntung kita juga bisa melihat aktivitas hewan liar disini<br />16.00 &ndash; 17.00 Perjalanan ke hotel, dinner nasi tempong mbok Wah<br />19.00 Hotel, check in dan istirahat<br /><br />Hari Keempat Destinasi yang dikunjungi: Kawah Ijen, Oseng Deles<br />00.00 &ndash; 00.30 Meeting service di lobby hotel<br />00.30 &ndash; 01.30 Perjalanan menuju Paltuding (Post terakhir sebelum pendakian ke puncak Gunung Ijen)<br />01.30 &ndash; 02.00 Paltuding, briefing sebelum pendakian<br />02.00 &ndash; 03.30 Pendakian ke puncak Gunung Ijen<br />03.30 &ndash; 04.00 Turun ke kawah untuk lebih dekat dengan api biru<br />04.00 &ndash; 04.30 Area api biru, foto session<br />04.30 &ndash; 05.15 Kembali ke puncak Ijen<br />05.15 &ndash; 06.00 Puncak Ijen, menikmati keindahan Kawah Ijen<br />06.00 &ndash; 07.30 Perjalan kembali ke paltuding<br />07.30 &ndash; 08.00 Paltuding, toilet break dan istirahat<br />08.00 &ndash; 09.00 Perjalanan kembali ke hotel<br />09.00 &ndash; 10.30 Hotel, sarapan dan mandi<br />10.30 &ndash; 11.00 Proses check out<br />11.00 &ndash; 11.15 Perjalanan ke Oseng Deles<br />11.15 &ndash; 12.00 Oseng Deles, belanja oleh-oleh<br />12.00 &ndash; 12.15 Perjalanan ke Rawon Bik Atik<br />12.15 &ndash; 12.45 Rawon Bik Atik, makan siang<br />12.45 &ndash; 12.30 Perjalanan ke Bandara Banyuwangi<br />12.30 Bandara Banyuwangi. Trip selesai</p>', 'foto_1608785336.jpg', '2020-12-20 01:06:08'),
(2, 'Libur Natal', '<p>sdfsadfsdf</p>', 'foto_1608785709.jpg', '2020-12-24 11:55:09');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pesanan`
--

CREATE TABLE `pesanan` (
  `id` int(10) NOT NULL,
  `user_id` int(10) NOT NULL,
  `tanggal_pesanan` date NOT NULL,
  `jam_pesan` int(10) NOT NULL,
  `status` varchar(255) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `pesanan`
--

INSERT INTO `pesanan` (`id`, `user_id`, `tanggal_pesanan`, `jam_pesan`, `status`, `date_created`) VALUES
(1, 1, '2020-12-21', 10, 'Sudah Dipesan', '2020-12-21 06:44:39'),
(2, 2, '2020-12-22', 10, 'Sudah Dipesan', '2020-12-21 07:13:56'),
(10, 2, '2020-12-24', 3, 'Sudah Dipesan', '2020-12-23 05:32:29'),
(12, 2, '2020-12-23', 2, 'Sudah Dipesan', '2020-12-23 05:32:40');

-- --------------------------------------------------------

--
-- Struktur dari tabel `users`
--

CREATE TABLE `users` (
  `id` int(10) NOT NULL,
  `nama_depan` varchar(255) NOT NULL,
  `nama_belakang` varchar(255) NOT NULL,
  `no_hp` varchar(16) NOT NULL,
  `email` varchar(225) NOT NULL,
  `password` varchar(255) NOT NULL,
  `level` int(1) NOT NULL,
  `status` int(1) NOT NULL,
  `date_created` datetime NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data untuk tabel `users`
--

INSERT INTO `users` (`id`, `nama_depan`, `nama_belakang`, `no_hp`, `email`, `password`, `level`, `status`, `date_created`) VALUES
(1, 'Admin', 'Satu', '085727216622', 'admin@admin.com', '$2y$10$kpi2EFACZCNQ3epoC/sF5OempzSLApT47zyIIGHZKTcp.s3G5VUhq', 0, 1, '2020-12-23 00:39:14'),
(2, 'Kevin', 'Marchelino', '1232132', 'marchelinokevin12@outlook.com', '$2y$10$kpi2EFACZCNQ3epoC/sF5OempzSLApT47zyIIGHZKTcp.s3G5VUhq', 1, 1, '2020-12-23 00:39:58'),
(3, 'Supri', 'Ansyah', '32423423', 'supri@supri.com', '$2y$10$KPQeXv5xQIVfZKK7gWB65uoddUb7XrSjvpmgevs63nMQphPWIUQze', 1, 1, '2020-12-23 00:39:14');

--
-- Indexes for dumped tables
--

--
-- Indeks untuk tabel `info`
--
ALTER TABLE `info`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  ADD PRIMARY KEY (`id`);

--
-- Indeks untuk tabel `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `email` (`email`);

--
-- AUTO_INCREMENT untuk tabel yang dibuang
--

--
-- AUTO_INCREMENT untuk tabel `info`
--
ALTER TABLE `info`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=3;

--
-- AUTO_INCREMENT untuk tabel `pesanan`
--
ALTER TABLE `pesanan`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT untuk tabel `users`
--
ALTER TABLE `users`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=4;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
