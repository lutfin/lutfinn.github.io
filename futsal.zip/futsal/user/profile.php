<?php
require_once("auth.php");
include("koneksi.php");

$id = $_SESSION['user']['id'];
if (isset($_POST['profile'])) {
    // ambil data dari formulir
    $nama_depan = $_POST['nama_depan'];
    $nama_belakang = $_POST['nama_belakang'];
    $email = $_POST['email'];
    $no_hp = $_POST['no_hp'];

    // buat query update
    $sql_up = "UPDATE users SET nama_depan='$nama_depan',nama_belakang='$nama_belakang', email='$email',no_hp='$no_hp' WHERE id = '$id'";
    $query_up = mysqli_query($kon, $sql_up);

    // apakah query update berhasil?
    if ($query_up) {
        echo "<script>alert('Data berhasil disimpan');</script>";
    } else {
        // kalau gagal tampilkan pesan
        die("Gagal menyimpan perubahan...");
    }
}


?>
<!DOCTYPE html>
<html lang="en">
<?php
include "template/header.php";
?>

<body id="page-top">

    <!-- Page Wrapper -->
    <div id="wrapper">

        <!-- Sidebar -->
        <?php
        include "template/sidebar.php";
        ?>
        <!-- End of Sidebar -->

        <!-- Content Wrapper -->
        <div id="content-wrapper" class="d-flex flex-column">

            <!-- Main Content -->
            <div id="content">

                <!-- Topbar -->
                <?php
                include "template/topbar.php";
                ?>
                <!-- End of Topbar -->

                <!-- Begin Page Content -->
                <div class="container-fluid">

                    <!-- Page Heading -->
                    <h1 class="h3 mb-2 text-gray-800">Profile</h1>

                    <!-- DataTales Example -->
                    <div class="card shadow mb-4">
                        <div class="card-header py-3">
                            <h6 class="m-0 font-weight-bold text-primary">Profile</h6>
                        </div>
                        <div class="card-body">
                            <?php
                            $sql = "SELECT * FROM users WHERE id = '$id'";
                            $query = mysqli_query($kon, $sql);

                            $data = mysqli_fetch_array($query);

                            ?>
                            <form action="" method="POST">
                                <label for="nama">Nama Lengkap</label>
                                <div class="form-group row">
                                    <div class="col">
                                        <input type="text" class="form-control form-control-user" id="nama_depan" name="nama_depan" placeholder="Nama Depan" value="<?= $data['nama_depan']; ?>" required>
                                    </div>
                                    <div class="col">
                                        <input type="text" class="form-control form-control-user" id="nama_belakang" name="nama_belakang" placeholder="Nama Belakang" value="<?= $data['nama_belakang']; ?>" required>
                                    </div>
                                </div>

                                <div class="form-group">
                                    <label for="email">Email</label>
                                    <input type="email" class="form-control" id="email" name="email" placeholder="name@example.com" value="<?= $data['email']; ?>">
                                    <small id="emailHelp" class="form-text text-muted">We'll never share your email with anyone else.</small>
                                </div>
                                <div class="form-group">
                                    <label for="no_hp">Nomor HP</label>
                                    <input type="text" class="form-control" id="no_hp" name="no_hp" placeholder="Nomor HP" value="<?= $data['no_hp']; ?>" required>
                                </div>
                                <button type="submit" value="Profile" name="profile" class="btn btn-primary my-1">Submit</button>
                            </form>
                        </div>

                    </div>
                </div>
                <!-- /.container-fluid -->

            </div>
            <!-- End of Main Content -->

            <!-- Footer -->
            <?php
            include "template/footer.php";
            ?>
            <!-- End of Footer -->

        </div>
        <!-- End of Content Wrapper -->

    </div>
    <!-- End of Page Wrapper -->

    <!-- Scroll to Top Button-->
    <a class="scroll-to-top rounded" href="#page-top">
        <i class="fas fa-angle-up"></i>
    </a>

    <!-- Logout Modal-->
    <?php
    include "template/logout_modal.php";
    include "template/script.php";

    ?>

</body>

</html>